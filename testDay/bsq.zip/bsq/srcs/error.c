/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: idocrat <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/04/20 18:08:16 by idocrat           #+#    #+#             */
/*   Updated: 2016/04/20 18:21:33 by idocrat          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

unsigned int	height_n_width(char *str)
{
	unsigned int	i;

	var_1 = get_height(str);
	while (i < var_1)
	{
		if (get_width(str[i - 1]) == get_width
}
